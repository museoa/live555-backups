// Version information for the "groupsock" library
// Copyright (c) 1996-2006 Live Networks, Inc.  All rights reserved.

#ifndef _GROUPSOCK_VERSION_HH
#define _GROUPSOCK_VERSION_HH

#define GROUPSOCK_LIBRARY_VERSION_STRING	"2006.03.16"
#define GROUPSOCK_LIBRARY_VERSION_INT		1142467200

#endif
